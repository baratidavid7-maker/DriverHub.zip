# DriverHub Simple (0.2)

A simple Android notification dashboard for driver/delivery offers. Shows only:
- Which selected driver app sent an order notification
- Fare shown in notification (or "Not shown")
- Distance shown in notification (or "Not shown")

Tap an offer to open the originating app. There is no accepting, rejecting, automation, screen capture, remote server, or account login. Nothing is sent over the network.

**Limitation:** Some driver apps do not put pay/distance inside normal Android notifications, or only show offers inside their own foreground screens. In those cases DriverHub cannot read that data. Multiple distances without a clear total are not guessed.

## Build
Use the existing GitHub Actions workflow in your repository. Upload/replace `DriverHub.zip` and check Actions -> Build DriverHub APK. This ZIP has top-level `DriverHub-Android/`, matching the existing workflow. Java 17, Android SDK 35, Gradle 8.9.

## Setup
Install `app-debug.apk` after a successful build, open DriverHub, select desired driver apps, and grant notification access in Android Settings. Leave notifications enabled for the source apps. Never interact with notifications while driving.
