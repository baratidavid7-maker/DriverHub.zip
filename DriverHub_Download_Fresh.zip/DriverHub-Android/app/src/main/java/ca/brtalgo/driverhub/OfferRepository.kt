package ca.brtalgo.driverhub

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArraySet

/** On-device only. A captured notification is NOT a platform API connection. */
data class DriverAlert(
    val key: String,
    val packageName: String,
    val appLabel: String,
    val title: String,
    val text: String,
    val postedAt: Long,
    val active: Boolean,
    val likelyOffer: Boolean
)

private data class NotificationControls(
    val open: PendingIntent?,
    val accept: PendingIntent?,
    val decline: PendingIntent?
)

object OfferRepository {
    private const val PREFS = "driverhub_alerts"
    private const val KEY_ALERTS = "alerts"
    private val alerts = LinkedHashMap<String, DriverAlert>()
    private val controls = HashMap<String, NotificationControls>()
    private val observers = CopyOnWriteArraySet<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())
    private var initialized = false

    fun initialize(context: Context) = synchronized(this) {
        if (initialized) return@synchronized
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_ALERTS, "[]") ?: "[]"
        try {
            val stored = JSONArray(raw)
            for (i in 0 until stored.length()) {
                val j = stored.getJSONObject(i)
                val item = DriverAlert(
                    j.getString("key"), j.getString("package"), j.optString("app"),
                    j.optString("title"), j.optString("text"), j.optLong("time"),
                    false, j.optBoolean("offer", false)
                )
                alerts[item.key] = item // restored entries are HISTORY, never active
            }
        } catch (_: Exception) {
            alerts.clear()
        }
        initialized = true
    }

    private fun persist(context: Context) {
        val array = JSONArray()
        alerts.values.sortedByDescending { it.postedAt }.take(100).forEach { item ->
            array.put(JSONObject().apply {
                put("key", item.key)
                put("package", item.packageName)
                put("app", item.appLabel)
                put("title", item.title)
                put("text", item.text)
                put("time", item.postedAt)
                put("offer", item.likelyOffer)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(KEY_ALERTS, array.toString()).apply()
    }

    fun watch(observer: () -> Unit) { observers.add(observer) }
    fun unwatch(observer: () -> Unit) { observers.remove(observer) }
    private fun notifyChanged() {
        main.post { observers.forEach { it.invoke() } }
    }

    fun snapshot(): List<DriverAlert> = synchronized(this) {
        alerts.values.sortedWith(compareByDescending<DriverAlert> { it.active }.thenByDescending { it.postedAt })
    }

    fun acceptAvailable(key: String): Boolean = synchronized(this) {
        alerts[key]?.active == true && controls[key]?.accept != null
    }

    fun declineAvailable(key: String): Boolean = synchronized(this) {
        alerts[key]?.active == true && controls[key]?.decline != null
    }

    fun perform(key: String, action: String): Boolean = synchronized(this) {
        val current = alerts[key] ?: return@synchronized false
        if (!current.active) return@synchronized false
        val ctl = controls[key] ?: return@synchronized false
        val pending = when (action) {
            "accept" -> ctl.accept
            "decline" -> ctl.decline
            else -> ctl.open
        } ?: return@synchronized false
        try {
            // Only invokes an explicit action supplied by the SOURCE notification.
            // This never clicks/scrapes/automates another app's UI.
            pending.send()
            true
        } catch (_: PendingIntent.CanceledException) {
            false
        } catch (_: SecurityException) {
            false
        }
    }

    fun openNotification(key: String): Boolean = synchronized(this) {
        val pending = controls[key]?.open ?: return@synchronized false
        try {
            pending.send()
            true
        } catch (_: Exception) { false }
    }

    fun expireAll(context: Context) = synchronized(this) {
        initialize(context)
        for ((key, value) in alerts) alerts[key] = value.copy(active = false)
        controls.clear()
        persist(context)
        notifyChanged()
    }

    fun remove(context: Context, key: String) = synchronized(this) {
        initialize(context)
        val existing = alerts[key] ?: return@synchronized
        alerts[key] = existing.copy(active = false)
        controls.remove(key)
        persist(context)
        notifyChanged()
    }

    fun capture(context: Context, sbn: StatusBarNotification, displayName: String) = synchronized(this) {
        initialize(context)
        if (!AppPrefs.isSelected(context, sbn.packageName)) return@synchronized
        val n = sbn.notification
        val extras = n.extras
        val title = (extras.getCharSequence(Notification.EXTRA_TITLE)?.toString() ?: "Notification").take(250)
        val body = (
            extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_TEXT)
                ?: extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.joinToString(" ")
                ?: "Tap to review in the source app"
            ).toString().take(1200)
        val likely = OfferParser.isOrder("$title $body")
        // Notification buttons are NOT guaranteed. Only literal Accept/Decline-like
        // actions from the notification are allowed, and only on a user tap.
        val accept = n.actions?.firstOrNull {
            Regex("(?i)^accept(?:\\b|$)").containsMatchIn(it.title?.toString() ?: "")
        }?.actionIntent
        val decline = n.actions?.firstOrNull {
            Regex("(?i)^(decline|reject)(?:\\b|$)").containsMatchIn(it.title?.toString() ?: "")
        }?.actionIntent
        alerts[sbn.key] = DriverAlert(sbn.key, sbn.packageName, displayName,
            title, body, sbn.postTime, true, likely)
        controls[sbn.key] = NotificationControls(n.contentIntent, accept, decline)
        if (alerts.size > 120) {
            val discard = alerts.values.sortedBy { it.postedAt }.take(alerts.size - 100)
            for (entry in discard) { alerts.remove(entry.key); controls.remove(entry.key) }
        }
        persist(context)
        notifyChanged()
    }

    fun forgetHistory(context: Context) = synchronized(this) {
        initialize(context)
        alerts.entries.removeAll { !it.value.active }
        persist(context)
        notifyChanged()
    }
}
