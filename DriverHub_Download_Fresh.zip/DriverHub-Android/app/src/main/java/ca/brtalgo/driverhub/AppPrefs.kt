package ca.brtalgo.driverhub

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

/** User-controlled allowlist; we do not scan unrelated notification content. */
object AppPrefs {
    private const val PREFS = "driverhub_settings"
    private const val SELECTED = "selected_packages"
    private const val CONFIGURED = "configured"

    data class InstalledApp(val label: String, val pkg: String)

    fun availableApps(context: Context): List<InstalledApp> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val matches = if (android.os.Build.VERSION.SDK_INT >= 33) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }
        return matches.asSequence()
            .filter { it.activityInfo.packageName != context.packageName }
            .map { InstalledApp(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
            .toList()
    }

    fun suggested(app: InstalledApp): Boolean {
        val value = "${app.label} ${app.pkg}".lowercase()
        if (value.contains("pro card") || value.contains("branch")) return false
        return listOf("uber driver", "ubercab.driver", "instacart", "shopper", "hopp",
            "dasher", "doordash.driver", "spark driver", "sparkdriver", "deliverypanda",
            "fantuan", "tasker").any { value.contains(it) }
    }

    fun initializeDefaults(context: Context) {
        val pref = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (!pref.getBoolean(CONFIGURED, false)) {
            val matches = availableApps(context).filter { suggested(it) }.map { it.pkg }.toSet()
            pref.edit().putStringSet(SELECTED, matches).putBoolean(CONFIGURED, true).apply()
        }
    }

    fun selected(context: Context): Set<String> =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(SELECTED, emptySet())?.toSet() ?: emptySet()

    fun isSelected(context: Context, pkg: String): Boolean = selected(context).contains(pkg)

    fun setSelected(context: Context, packages: Set<String>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putStringSet(SELECTED, packages.toSet()).putBoolean(CONFIGURED, true).apply()
    }
}
