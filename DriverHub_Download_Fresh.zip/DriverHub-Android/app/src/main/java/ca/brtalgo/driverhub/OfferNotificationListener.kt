package ca.brtalgo.driverhub

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Runs only after the user explicitly grants notification access in Settings. */
class OfferNotificationListener : NotificationListenerService() {
    override fun onCreate() {
        super.onCreate()
        OfferRepository.initialize(applicationContext)
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        OfferRepository.expireAll(applicationContext)
        activeNotifications?.forEach { onNotificationPosted(it) }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null || !AppPrefs.isSelected(applicationContext, sbn.packageName)) return
        val label = try {
            val pm = packageManager
            @Suppress("DEPRECATION")
            val info = pm.getApplicationInfo(sbn.packageName, 0)
            pm.getApplicationLabel(info).toString()
        } catch (_: Exception) { sbn.packageName }
        OfferRepository.capture(applicationContext, sbn, label)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn != null) OfferRepository.remove(applicationContext, sbn.key)
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        OfferRepository.expireAll(applicationContext)
    }
}
