package ca.brtalgo.driverhub

import android.app.Activity
import android.app.AlertDialog
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.DateFormat
import java.util.Date

/** One screen: source app, fare, and distance (when present in notification text). */
class MainActivity : Activity() {
    private val canvasColor = Color.rgb(10, 16, 27)
    private val surface = Color.rgb(24, 34, 49)
    private val outline = Color.rgb(49, 66, 83)
    private val primary = Color.rgb(246, 248, 251)
    private val muted = Color.rgb(169, 182, 195)
    private val accent = Color.rgb(103, 235, 183)
    private lateinit var content: LinearLayout
    private val observer: () -> Unit = { if (!isFinishing) draw() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = canvasColor
        window.navigationBarColor = canvasColor
        AppPrefs.initializeDefaults(this)
        OfferRepository.initialize(this)
        OfferRepository.watch(observer)
        val scroll = ScrollView(this).apply {
            setBackgroundColor(canvasColor)
            isFillViewport = true
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(19), dp(30), dp(19), dp(28))
        }
        scroll.addView(content)
        setContentView(scroll)
        draw()
    }

    override fun onResume() {
        super.onResume()
        if (::content.isInitialized) draw()
    }

    override fun onDestroy() {
        OfferRepository.unwatch(observer)
        super.onDestroy()
    }

    private fun dp(value: Int) = (resources.displayMetrics.density * value + .5f).toInt()

    private fun bg(color: Int, radius: Int = 17, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        stroke?.let { setStroke(dp(1), it) }
    }

    private fun text(value: String, size: Float, color: Int = primary, heavy: Boolean = false) =
        TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (heavy) typeface = Typeface.create("sans-serif", Typeface.BOLD)
        }

    private fun spacer(parent: LinearLayout, height: Int) {
        parent.addView(View(this), LinearLayout.LayoutParams(1, dp(height)))
    }

    private fun linkButton(title: String, onClick: () -> Unit): TextView =
        text(title, 13f, accent, true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(10), dp(10), dp(10), dp(10))
            setOnClickListener { onClick() }
        }

    private fun hasNotificationAccess(): Boolean {
        val all = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        return all.split(':').any {
            ComponentName.unflattenFromString(it)?.packageName == packageName
        }
    }

    private fun chooseApps() {
        val apps = AppPrefs.availableApps(this)
        if (apps.isEmpty()) {
            Toast.makeText(this, "No apps found", Toast.LENGTH_SHORT).show()
            return
        }
        val selected = AppPrefs.selected(this).toMutableSet()
        val labels = apps.map { it.label }.toTypedArray()
        val checked = BooleanArray(apps.size) { selected.contains(apps[it].pkg) }
        AlertDialog.Builder(this)
            .setTitle("Choose delivery apps")
            .setMultiChoiceItems(labels, checked) { _, index, state ->
                if (state) selected.add(apps[index].pkg) else selected.remove(apps[index].pkg)
            }
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ -> AppPrefs.setSelected(this, selected); draw() }
            .show()
    }

    private fun openOffer(item: DriverAlert) {
        try {
            if (item.active && OfferRepository.openNotification(item.key)) return
            val intent = packageManager.getLaunchIntentForPackage(item.packageName)
            if (intent != null) startActivity(intent)
            else Toast.makeText(this, "Open ${item.appLabel} to view the order", Toast.LENGTH_LONG).show()
        } catch (_: Exception) {
            Toast.makeText(this, "Could not open the driver app", Toast.LENGTH_SHORT).show()
        }
    }

    private fun draw() {
        if (!::content.isInitialized) return
        content.removeAllViews()
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val heading = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        heading.addView(text("DriverHub", 17f, accent, true))
        spacer(heading, 4)
        heading.addView(text("New orders", 29f, primary, true))
        header.addView(heading, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(linkButton("Choose apps") { chooseApps() })
        content.addView(header)
        spacer(content, 19)

        val allowed = hasNotificationAccess()
        val chosen = AppPrefs.selected(this).size
        if (!allowed) {
            val setup = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = bg(surface, 17, outline)
                setPadding(dp(16), dp(16), dp(16), dp(16))
            }
            setup.addView(text("Enable notifications", 17f, primary, true))
            spacer(setup, 6)
            setup.addView(text("Allow DriverHub to read alerts from your selected driver apps.", 13f, muted))
            spacer(setup, 12)
            setup.addView(linkButton("Enable access  →") {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            })
            content.addView(setup)
            spacer(content, 18)
        }
        content.addView(text(if (allowed) "●  Listening · $chosen apps selected"
            else "○  Notification access is off", 13f, if (allowed) accent else muted))
        spacer(content, 14)

        val now = System.currentTimeMillis()
        // Only offers from monitored apps; do not show account updates or routine messages.
        val offers = OfferRepository.snapshot().filter {
            it.likelyOffer && AppPrefs.isSelected(this, it.packageName) &&
                it.postedAt >= now - 12 * 60 * 60 * 1000L
        }.sortedByDescending { it.postedAt }.take(30)
        if (offers.isEmpty()) {
            val empty = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                background = bg(surface, 17, outline)
                setPadding(dp(18), dp(42), dp(18), dp(42))
            }
            empty.addView(text("No new orders", 19f, primary, true))
            spacer(empty, 8)
            empty.addView(text(
                if (!allowed) "Enable notification access above."
                else if (chosen == 0) "Tap Choose apps to select your driver apps."
                else "New order notifications will appear here.", 13f, muted
            ).apply { gravity = Gravity.CENTER })
            content.addView(empty)
        } else {
            offers.forEach { addOrder(it) }
        }
        spacer(content, 16)
        content.addView(text(
            "Fare and distance are shown only when the original app includes them in the notification. " +
                "Tap an order to open the original app. Offers may expire.",
            12f, muted
        ))
    }

    private fun addOrder(order: DriverAlert) {
        val parsed = OfferParser.parse("${order.title} ${order.text}")
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg(surface, 17, outline)
            setPadding(dp(17), dp(16), dp(17), dp(16))
            setOnClickListener { openOffer(order) }
            isClickable = true
        }
        val line1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        line1.addView(text(order.appLabel, 17f, primary, true),
            LinearLayout.LayoutParams(0, -2, 1f))
        line1.addView(text(if (order.active) "NEW" else "PAST", 11f,
            if (order.active) accent else muted, true))
        panel.addView(line1)
        spacer(panel, 8)

        val values = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val fareCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fareCol.addView(text("FARE", 11f, muted, true))
        spacer(fareCol, 4)
        fareCol.addView(text(parsed.fare ?: "Not shown", if (parsed.fare == null) 15f else 27f,
            if (parsed.fare == null) muted else accent, true))
        values.addView(fareCol, LinearLayout.LayoutParams(0, -2, 1f))
        val distanceCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        distanceCol.addView(text("DISTANCE", 11f, muted, true))
        spacer(distanceCol, 4)
        distanceCol.addView(text(parsed.distance ?: "Not shown", if (parsed.distance == null) 15f else 25f,
            if (parsed.distance == null) muted else primary, true))
        values.addView(distanceCol, LinearLayout.LayoutParams(0, -2, 1f))
        panel.addView(values)
        spacer(panel, 10)
        panel.addView(text("${DateFormat.getTimeInstance(DateFormat.SHORT).format(Date(order.postedAt))}  ·  Tap to open in app →", 11f, muted))
        content.addView(panel, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(12)
        })
    }
}
