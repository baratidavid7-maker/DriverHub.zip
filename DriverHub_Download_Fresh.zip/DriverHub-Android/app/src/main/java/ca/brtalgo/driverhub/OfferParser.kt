package ca.brtalgo.driverhub

/**
 * Parses only the text the source app includes in its Android notification.
 * No price or distance is estimated from a map, offer screen, or network API.
 */
data class OfferSummary(val fare: String?, val distance: String?)

object OfferParser {
    private val currency = Regex(
        """(?i)(?<![\p{L}\d])(?:CA\$|C\$|US\$|CAD\s*\$?|USD\s*\$?|\$)\s*\d{1,4}(?:,\d{3})*(?:\.\d{1,2})?"""
    )
    private val distance = Regex(
        """(?i)\b\d{1,3}(?:[.,]\d{1,2})?\s*(?:km|kilometers?|kilometres?|mi|miles?)\b"""
    )
    private val explicitDistance = Regex(
        """(?i)\b(?:(?:total)(?:\s*(?:driving\s*)?distance)?|(?:trip|delivery|route)\s*(?:driving\s*)?distance)\s*[:=-]?\s*(\d{1,3}(?:[.,]\d{1,2})?\s*(?:km|kilometers?|kilometres?|mi|miles?))\b"""
    )
    private val explicitPay = Regex(
        """(?i)\b(?:fare|earnings|earn|estimated\s+pay|payout|pay)\s*[:=-]?\s*((?:CA\$|C\$|US\$|CAD\s*\$?|USD\s*\$?|\$)\s*\d{1,4}(?:,\d{3})*(?:\.\d{1,2})?)"""
    )
    private val requestText = Regex(
        """(?i)\b(?:new\s+(?:order|request|offer|trip|delivery|batch|ride|task)|(?:order|trip|delivery|ride|batch|task)\s+(?:request|offer|available)|incoming\s+(?:order|request|offer|trip)|accept\s+(?:order|trip|ride|offer)|pickup\s+(?:request|available)|offer\s+(?:expires|available))\b"""
    )
    private val nonOrder = Regex(
        """(?i)\b(?:weekly\s+(?:summary|earnings)|payment\s+received|tip\s+added|order\s+(?:completed|delivered)|trip\s+completed|deposit\s+(?:received|sent)|special\s+promotion|account\s+alert|your\s+statement|receipt\s+for)\b"""
    )

    fun parse(message: String): OfferSummary {
        val pay = explicitPay.find(message)?.groups?.get(1)?.value ?: currency.find(message)?.value
        val distances = distance.findAll(message).map { it.value.trim() }.distinct().toList()
        val total = explicitDistance.find(message)?.groups?.get(1)?.value?.trim()
        val reportedDistance = total ?: if (distances.size == 1) distances.first() else null
        return OfferSummary(pay?.trim(), reportedDistance)
    }

    fun isOrder(message: String): Boolean {
        if (nonOrder.containsMatchIn(message)) return false
        val info = parse(message)
        return requestText.containsMatchIn(message) || (info.fare != null && info.distance != null)
    }
}
